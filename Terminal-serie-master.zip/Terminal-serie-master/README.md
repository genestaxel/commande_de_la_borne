# Terminal-serie
Commande VT100 permettant d'agir sur un hyperTerminal série
//boujour//
